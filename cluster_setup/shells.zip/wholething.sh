#!/usr/bin/env bash
source variables.sh

./input.sh II WC

./runBoth.sh

